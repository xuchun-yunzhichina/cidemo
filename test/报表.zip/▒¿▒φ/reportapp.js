/*! 
 * 报表业务操作
 * @author Fredric 
 * @date 2014-10-24
 */
//var tenantdao = require("../admindao/tenant");

/*-
 * 统计不同员工数量的企业分布
 */
exports.getAdminReport1 = function(callback){
	var data = "<graph caption='企业规模统计' xAxisName='' yAxisName='' showNames='1' decimalPrecision='0' formatNumberScale='0' baseFontSize='14'>";

			data += " <set label='2004' value='37800' link='newChart-xml-2004-quarterly' />";
			data += " <set label='2005' value='21900' link='newChart-xml-2005-quarterly' />";
			data += "<set label='2006' value='32900' link='newChart-xml-2006-quarterly' />";
			data += "<set label='2007' value='39800' link='newChart-xml-2007-quarterly' />";
            data += "<linkeddata id='2004-quarterly'>";
            data += "<chart caption='部门A' subcaption='For the year 2004' xAxisName='Quarter' yAxisName='Sales'>";
            data += " <set label='Q1' value='11700' link='newChart-xml-2008-quarterly'/>";
            data += " <set label='Q2' value='8600' />";
            data += "<set label='Q3' value='6900' />";
            data += "<set label='Q4' value='10600' />";
            data += "</chart>";
            data += "</linkeddata>";
            data += "<linkeddata id='2005-quarterly'>";
            data += "<chart caption='部门B' subcaption='For the year 2005' xAxisName='Quarter' yAxisName='Sales'>";
            data += " <set label='Q1' value='11700' />";
            data += " <set label='Q2' value='8600' />";
            data += "<set label='Q3' value='6900' />";
            data += "<set label='Q4' value='10600' />";
            data += "</chart>";
            data += "</linkeddata>";
			data += "</graph>";
			
			return callback(null,data);


}

